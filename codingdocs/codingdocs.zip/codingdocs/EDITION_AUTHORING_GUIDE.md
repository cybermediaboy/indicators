# Edition Authoring Guide

Edition = a pre-configured indicator variant for a specific market regime, asset class, or workflow.

## Edition Creation Checklist
1. Inherit base indicator's input groups verbatim
2. Override only the inputs that distinguish this edition
3. Tag edition name in indicator title: `"CVB Pro — Mean-Reversion Edition"`
4. Document active signals + suppressed signals in header comment
5. List dependency libs with version pins
6. Run smoke test on intended asset class

## Naming Convention
`{Base}-{Regime}-{Class}` e.g. `CVB-MR-Crypto`, `IHD-Trend-Equity`

## Quen Template (paste into new edition file)
```
//@version=6
// Edition: {NAME}
// Base: {BASE_INDICATOR_VERSION}
// Active signals: {LIST}
// Suppressed: {LIST}
// Optimized for: {ASSET_CLASS} / {TIMEFRAME} / {REGIME}
// Lib pins: CausalityLib v{X}, TAUtilityLib v{Y}, KalmanEngineLib v{Z}
indicator("{TITLE}", overlay={BOOL}, max_labels_count=500, max_lines_count=500)
```

## Edition Hierarchy
- Tier-1 editions (one per regime): MR, Trend, Squeeze
- Tier-2 editions (asset-specialized): Crypto-MR, Equity-Trend
- Tier-3 editions (workflow): Scalp, Swing, Position
