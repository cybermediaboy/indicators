# COMPILE_ERROR_COOKBOOK.md — Navigation Hub

Sub-files in `cookbook/`:
- `3.1_compile_blockers.md` — hard compiler rejects (~60 entries)
- `3.2_runtime_errors.md` — RE10045, history-limit, memory-limit, NaN cascade (~12)
- `3.3_logic_silent_bugs.md` — wrong output, no error (~16)
- `3.4_token_budget_bugs.md` — 80k AST cap (~10)
- `3.5_performance_limit_bugs.md` — heavy-bar gating, request cap (~14)

## §0 Quick Navigation

### 0.1 By Keyword (alphabetical)
`array.sort` → 3.1#G74 · `barstate.islastconfirmedhistory` → 3.1#G79 · `bgcolor` → 3.1#G15 · `exp(0)` → 3.3#G53 · `fixnan` → 3.3#G52 · `for ... by -1` → 3.1 · `hline` → 3.1#G15 · `last_bar_index` → 3.2#G51 · `linewidth` → 3.1#G33 · `location.absolute` → 3.1#G55 · `math.clamp` → 3.1 (missing) · `math.covariance` → 3.1#G50 · `max_bars_back` → 3.2#G1 · `nz` (bool) → 3.1#G76 · `plotchar` → 3.1#G17 · `plotshape` → 3.1#G15 · `RE10045` → 3.2#G78 · `request.footprint` → 3.5#G92 · `request.security_lower_tf` → 3.5#G28 · `series int` → 3.1#G33 · `syminfo.bid/ask` → 3.5#G89 · `ta.correlation` → 3.1#G75 · `ta.covariance` → 3.1#G50 · `ta.linreg/ema` → 3.1#G71 · `tuple unpack` → 3.1#G8 · `UDT dot-access` → 3.4#G29 · `var array` → 3.1 · `varip` → 3.3#G23 · `xloc.bar_index` → 3.2#G1

### 0.2 By Concept
- **Scope leaks** → 3.1 (G3, G80)
- **Type strictness** → 3.1 (G33, G34, G68, G71, G75, G76)
- **Buffer limits** → 3.2 (G1)
- **Dimensional sanity** → 3.3 (G82, G83)
- **Lifecycle management** → 3.1/3.3 (G24, G62)
- **Token economics** → 3.4 (G29, G34, G54, G77)
- **Init traps** → 3.3 (G32, G53, G78)
- **NA propagation** → 3.3 (G30, G31, G52)
- **Plan/version gating** → 3.5 (G92, G93)

### 0.3 By Symptom (situation-first)
- "Indicator goes flat at -6.85" → 3.3#G30 (stdev collapse)
- "Labels disappear after 1000 bars" → 3.2#G1 (label cap 500)
- "Stuck at zero" → 3.3#G31 (nz zero injection)
- "Explosive band widths" → 3.3#G82 (dimensional explosion)
- "Compiles but breaks on 5m TF" → 3.5#G28 (max lookback)
- "Indicator breaks on weekends" → 3.3#G52 (NA cascade)
- "Wrong price scale after accumulation" → 3.3#G53 (exp(0) init)
- "Replay mode broken" → 3.2#G51 (last_bar_index)
- "Token limit exceeded 80k" → 3.4#G29, G34, G54, G77
- "Memory limit exceeded" → 3.5#G28
- "Shape not visible on pane" → 3.1#G55 (location.absolute)
- "Already defined" → 3.1 (forward declaration redeclaration)
- "Already declared identifier" → 3.1#G3
- "Z-score = -6.85" → 3.3#G30

### 0.4 By Pine Version
- **v5 only** → 550 local scope, no `export type` requirement
- **v6 only** → maps, UDTs first-class, enums, `runtime.log`, dynamic requests in loops, `request.security_lower_tf` improvements
- **v6 + Premium** → `request.footprint()` (Jan 2026, G92)
- **Both** → most type-strictness rules, scope rules, buffer limits

## §1 Limits Reference Card
See G1 in EUGENES_PINE_PRINCIPLES.md (table of 11 distinct ceilings).

## §2 Pre-Compilation Checklist (merged into entries)
Each catalog entry's `Prevention` field carries the checklist text inline.

## §4 Anti-Pattern Catalog (16 entries)
See MIGRATION_GUIDE.md "Anti-Patterns" section.

## §5 Cross-Indicator Pattern Library (15 recipes)
1. RTL label create-or-update + GC recreation (G24)
2. Tick-based chunked state machine (G29 + CHUNKED_EXECUTION_PATTERNS.md)
3. Lazy on-demand aggregation (G23)
4. Single-render-state UDT fields (G25)
5. Heavy-bar method fallback (G6)
6. Periodic rescan idiom (G41)
7. Rolling-percentile adaptive threshold (G43)
8. Domain-init pattern (G32)
9. Matrix init in barstate.isfirst (G40)
10. Confidence → transparency mapping (G44)
11. N×M oscillator mode dispatch (G42)
12. RTH session-state machine (G38)
13. Tier-fallback dispatch for plan-restricted features (G88)
14. Live-only-overlay realtime data (G89)
15. request.security budget accounting table (G87)

## §6 Pine v5 → v6 Migration Quick Diffs
See MIGRATION_GUIDE.md Phase 2.

## §7 AI-Coder Self-Audit Loop
See AI_CODER_PROMPT_TEMPLATE.md Section E.

## §8 Index of External References
- `CHUNKED_EXECUTION_PATTERNS.md` ← §5#2
- `EUGENES_PINE_PRINCIPLES.md` G1-G98
- `LIBRARY_UPDATE_INSTRUCTIONS.md`
- `MIGRATION_GUIDE.md`
- `AI_CODER_PROMPT_TEMPLATE.md`
- `EDITION_AUTHORING_GUIDE.md`
