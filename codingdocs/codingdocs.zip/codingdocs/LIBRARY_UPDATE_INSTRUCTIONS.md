# Library Update Instructions

Stages 0-3 protocol for updating Pine libraries with cross-edition compatibility.

## Stage 0 — Pre-flight
- Confirm SPoT (G0) for every exported field
- Verify `export type` declarations match across libs (G26)
- Check var count budget per importer (G2)

## Stage 1 — Per-Lib Checklist
For each library file:
- [ ] One-line purpose at top (G7)
- [ ] All exported UDTs use `export type T` (v6, G26)
- [ ] No external lib dependency unless declared (G73)
- [ ] LogLib flush test: BUFFERED mode triggers at ~4000 chars OR 2500 lines; PER_BAR uses `barstate.isconfirmed`; explicit `flush()` only at natural boundaries
- [ ] No global `max_bars_back` modification (G1)
- [ ] Matrix dimensions = const int (G68)

## Stage 2 — Cross-Lib Compatibility
- UDT field name stability (additive only; never rename, never reorder)
- Tuple return arity stability (additive only at end)
- Public function signatures locked once published

## Stage 3 — Importer Validation
- Token budget recheck (each consumer)
- Var budget recheck per consumer
- Compile + runtime smoke test on minimum-history symbol

## Library-Specific Notes
- **CausalityLib**: granger/copula functions require simple int len (G75)
- **MCLib**: pre-populate arrays at declaration to avoid RE10045 (G78)
- **MLLib**: KNN distance arrays — bounds-checked access only
- **TAUtilityLib**: label management functions handle full lifecycle (G62)
- **KalmanEngineLib**: Z-score-space pattern (G84) when input domain varies
