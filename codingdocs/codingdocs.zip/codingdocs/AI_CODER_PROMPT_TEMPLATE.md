# AI Coder Prompt Template

Inject this verbatim into AI coding sessions for Pine v5/v6 work.

## Section A — Hard Rules (never violate)
1. Single-pass declaration: ALL variables declared BEFORE use (G3)
2. No `plot/hline/bgcolor` inside `if` blocks — use `cond ? val : na` (G15)
3. `linewidth`/`style` require `input int`, wrap with `math.max(1, ...)` (G33)
4. All `if`/`switch` branches return same type; `float()` wrap literals (G34)
5. `for` step > 0 only; reverse bounds for descending iteration
6. No comma-separated statements; one per line (G81)
7. Var count target < 300, hard cap < 500 (G2)
8. `varip` only for counter accumulation, never for rendered state (G23)
9. Date-range guards on heavy LTF (G28)
10. Tuple unpacking: declare without type annotations, then `:=` (G8)

## Section B — Type Strictness
- `ta.linreg/ta.ema/ta.sma` → simple int len, pre-compute variants (G71)
- `ta.correlation` → int len, not float (G75)
- `nz()` → numeric only, never bool (G76)
- `array.sort` → named args `id=`, `order=` (G74)
- Matrix dims → const int (G68)
- No `ta.covariance` — manual `EXY - EX·EY` (G50)

## Section C — Logic-Silent Bug Avoidance
- Never feed `nz(x, 0.0)` into `ta.stdev` (G30)
- Domain-init pattern for Kalman: `var float x = na` + `if na(x) x := seed` (G32)
- Normalize to ATR before squaring price values (G82)
- Multiply Kalman normalized uncertainty by `ta.atr(100)` (G83)
- Synthetic log ratios init to `math.log(close/basket_idx)`, not 0.0 (G53)
- `fixnan` on EMA chains for weekend NA cascade (G52)

## Section D — Logger / Diagnostics
- LogLib BUFFERED: auto-flush at ~4000 chars OR 2500 lines
- PER_BAR mode: `barstate.isconfirmed`, never `islast`
- Explicit `flush()` only at natural boundaries (RCOM completion, etc.)
- Never use `barstate.islast` as primary trigger

## Section E — Self-Audit Loop (G94-G96)
1. Compile-only fast loop (~30s) — errors only
2. Full mode (~2-3min) — compile + 8s chart-load wait + runtime scan
3. Parse errors via schema: `{line, col, message, type}`
4. Multi-source runtime detection: legend buttons + dataProblem icons + toast notifications

## Section F — When in Doubt
Consult `COMPILE_ERROR_COOKBOOK.md` keyword/concept/situation index BEFORE writing.
