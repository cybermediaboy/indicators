# Eugene's Pine Script Principles (G1–G98)

Canonical principles distilled from 5 indicators (CMD-Unified, CVB v20, IHD-Osc, CVB v1, TV-Constrained spec), 50 deduplicated error trajectories, and trajectory 3c7c97da.

## Axiom #0 — Single Point of Truth (SPoT)
Every value rendered or used in logic has exactly one canonical source variable; downstream consumers read, never recompute.

## Tier-1 Canonical Principles (frequency ≥2 OR severity high)

### G1 — Buffer-limit awareness (multiple ceilings, not one)
| Limit | Value | Applies to |
|---|---|---|
| `max_bars_back` | 5000 | `[]` history reference |
| Default history buffer | 902 | `line.get_x1`/`label.get_x` age checks |
| Hard label cap | 500 | label objects on chart |
| Hard line cap | 500 | line objects on chart |
| Array element cap | 100,000 | `array.new` + push |
| `xloc.bar_index` past | 10,000 | future positioning |
| `xloc.bar_index` future | 500 | label/line forward placement |
| Local scope count | 550 (v5) / unlimited (v6 since Feb 2025) | inline functions |
| Main body lines | ~2000 | total script body |
| Token AST cap | 80,000 | total AST nodes |
| `request.security()` calls | 40 | total per script |

### G2 — Var limit hard cap < 500, practical target < 300; UDT instance = 1 slot
### G3 — Single-pass declaration order; no forward references
### G4 — `var` keyword = persistence across bars; without `var` = recalc each bar
### G5 — Never modify globals inside functions; return tuple, unpack at global with `:=`
### G6 — Heavy-bar gating with method fallback (5×): Spearman→Pearson, full→cheap, gated by `barstate.islast` or date window
### G7 — Library role clarification: every lib has a one-line purpose statement at top
### G8 — Tuple unpacking: declare variables first without type annotations inside brackets, then `:=`
### G15 — Never put `plot()`/`hline()`/`bgcolor()` inside `if` blocks (4×) — use `condition ? value : na`
### G16 — `barcolor()` has no `force_overlay` parameter
### G17 — `plotchar()` `char` accepts a single character, not strings
### G23 — `varip` counters → on-demand aggregation (avoid drift on chart reload)
### G24 — Label create-or-update with realtime maintenance + GC recreation (3×)
### G25 — Single-render-state UDT fields with `*final` suffix convention
### G26 — `export type` for cross-file UDT (v6 mandatory)
### G28 — Date-range guards required for heavy LTF processing
### G29 — UDT dot-notation costs 3 tokens vs 1 for local var; extract before hot-path math
### G30 — `ta.stdev` collapse: never feed `nz(x, 0.0)` into stdev; injects fake zeros
### G31 — `nz(x, 0.0)` zero-injection silently kills oscillators
### G32 — Domain-init pattern for Kalman/EMA: `var float kf_x = na` then `if na(kf_x) kf_x := seed`
### G33 — `linewidth`/`style` require `input int`, not `series int` — use `math.max(1, ...)` wrapper or dual-plot
### G34 — All `if`/`switch` branches must return same type — wrap literals with `float()`
### G37 — Mode-toggle dispatch via single string input, not scattered branches
### G38 — RTH session-state machine (US/Asia/EU)
### G40 — Matrix init in `barstate.isfirst` block
### G41 — Periodic rescan idiom: `bar_index - last_scan >= interval`
### G42 — N×M oscillator mode dispatch via string lookup table
### G43 — Rolling-percentile adaptive thresholds (`*_p90/p80/p20/p05`)
### G44 — Confidence → transparency mapping
### G68 — Matrix dimensions must be const int
### G71 — `ta.linreg`/`ta.ema` simple int length — pre-calculate variants, ternary select
### G74 — `array.sort` named args (`id=`, `order=`)
### G75 — `ta.correlation` int len, not float
### G76 — `nz` rejects bool — convert via `cond ? 1 : 0`
### G80 — `var` declared in `if`-block + used in `plot` → declare at script scope, `:=` inside block
### G82 — Dimensional explosion: normalize to ATR before squaring price values
### G83 — Kalman P11 dimensional collapse — multiply normalized uncertainty by `ta.atr(100)` to project to price space

## Tier-2 Annex (single occurrence, broadly applicable)
G49 token UDT-penalty · G50 missing `ta.covariance` · G51 replay-mode `last_bar_index` · G52 `fixnan` for weekend gaps · G53 `exp(0)=1` synthetic log ratio init · G54 dead-code token cost · G55 `location.absolute` broken on non-overlay · G62 label lifecycle (ref + reset + delete + nullify) · G77 main-body extraction to functions · G78 RE10045 array bounds · G79 `barstate.islastconfirmedhistory` for early checks · G81 comma-separated void calls forbidden · G84 Z-score-space Kalman pattern · G85 adaptive R from agreement EMA · G86 4-quadrant fill gating

## Tier-3 Cookbook Recipes (situational)
G56 dual flash/trend lookback · G63 `ta.kama/t3/trima/frama/sum` build-specific · G64 `input.options` rejects global arrays · G65 `syminfo.timezone` ≠ user-local · G66 instant-direction vs correlation-lag · G67 nested `request.security` forbidden · G69 hierarchical plot gating · G70 bandwidth color-transition state machine · G72 separate scalar/tuple variants · G73 library self-containment · G87 `request.security` budget table · G88 tier-fallback dispatch · G89 live-only-overlay realtime data · G90 weighted composite with IC tuning · G91 signal-card schema · G92 plan-gated v6 features · G93 v6-only features cookbook · G94 compiler-error parsing schema · G95 runtime error 3-source detection · G96 dual compilation modes · G97 clipboard-paste TV automation · G98 `domcontentloaded` vs `networkidle`

## Stop Conditions
- Var count > 500 → refactor before adding features
- Token AST > 70k → audit dead code (G54), extract main body (G77), collapse UDT dot-access (G29)
- Heavy LTF without date guard → block deploy
