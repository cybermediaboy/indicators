# Migration Guide

7-phase protocol for migrating indicators between Pine versions or library generations.

## Phase 1 — Inventory
- List all `import` statements
- List all UDT instances and their field counts
- Count `request.security` calls
- Compute current var count and token estimate

## Phase 2 — Version Diff
v5 → v6 changes:
- Local scope: 550 → unlimited (Feb 2025)
- `export type` becomes mandatory for cross-file UDT (G26)
- `request.footprint()` available (Premium-gated, G92)
- Maps + UDTs first-class
- Enums replace string-ternary regime state
- `runtime.log()` for non-chart debug
- Dynamic requests in loops

## Phase 3 — Library Compatibility Sweep
- Verify lib version pins match new base
- Re-export UDT signatures if cross-lib
- Run LogLib flush behavior test (G24, BUFFERED/PER_BAR)

## Phase 4 — Type-Strictness Audit
Run through Section B of AI_CODER_PROMPT_TEMPLATE checklist.

## Phase 5 — Logic-Silent Bug Sweep
- `nz` not feeding `ta.stdev` (G30)
- Kalman init pattern (G32)
- Dimensional sanity for squared price terms (G82, G83)

## Phase 6 — Var/Token Budget Recheck
- Var < 300 ideal, < 500 hard cap
- Token AST < 70k headroom

## Phase 7 — Smoke Test Matrix
| TF | Asset | Expected pass |
|---|---|---|
| 5m | BTCUSDT | no flatline (G86), no NaN cascade (G52) |
| 1h | SPX | RTH session-state machine activates (G38) |
| 1d | EURUSD | weekend gap doesn't break EMA chain (G52) |

## Anti-Patterns (never carry forward)
- `varip` counters that drift on chart reload
- Scattered if-mode-toggle branches everywhere
- Tuple-return raw indexing `f()[i]`
- Forward declarations + redeclaration
- `nz(x, 0.0)` inside `ta.stdev/ta.sma`
- Hardcoded scalars instead of normalized ratios
- 5+ level nested ternaries instead of switch-case dispatch
- Symmetric multiplier on competing dual streams
- `location.absolute` on indicator panes (G55)
- Library depending on uncommitted external library (G73)

## 3 Migration Examples
**Ex1**: CVB v1 → CVB v20: scalar Kalman fields → matrix UDT → KalmanEngineLib (G40, G84)
**Ex2**: IHD-Osc v5 → v6: lib boundaries restructured for `export type` (G26)
**Ex3**: CMD-Unified imports CausalityLib v3 → v4: granger function signature change, ternary select (G71)
